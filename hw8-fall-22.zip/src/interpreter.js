"use strict";

function interpExpression(state, expr) {
  // TODO
}

function interpStatement(state, stmt) {
  // TODO
}

function interpProgram(stmts) {
  // TODO
}

// DO NOT REMOVE
module.exports = {
  interpExpression,
  interpStatement,
  interpProgram,
};
