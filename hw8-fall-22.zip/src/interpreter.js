function interpExpression(state, expr) {
  // TODO
}

function interpStatement(state, stmt) {
  // TODO
}

function interpProgram(stmts) {
  // TODO
}

module.exports = {
  interpExpression,
  interpStatement,
  interpProgram,
};
