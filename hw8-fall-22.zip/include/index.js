"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var parse_1 = require("./parse");
exports.parseExpression = parse_1.parseExpression;
exports.parseProgram = parse_1.parseProgram;
